./switch local_port=27030 local_link=long remote_link=short remote_ip=144.80.30.177 remote_port=5803 head_len=29 msg_type=trm logfile=/home/hn/run/log/switch_sev.log&
